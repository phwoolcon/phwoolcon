<?php

/*
 * Register :package_name components
 */
/*
use Phwoolcon\Skeleton\:psr_packageService;

:psr_packageService::register($di);
*/

/*
 * Make DI injections
 */
/*
use Phwoolcon\Skeleton\Model\User as :psr_packageUser;
use Phwoolcon\Model\User as PhwoolconUser;

$di->set(PhwoolconUser::class, :psr_packageUser::class);
*/
